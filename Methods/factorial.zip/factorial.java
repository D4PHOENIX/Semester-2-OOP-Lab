package com.company;
import java.util.Scanner;

class Recursion{
    public int factor(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factor(n - 1);
        }
    }
}

public class factorial {
    static void fact(int x){
        int fact = 1;
        for (int i = x; i > 0 ; i--){
            fact *= i;
        }
        System.out.println("The Factorial of " + x + " is " + fact + ".");
    }
    public static void main(String[] args){
        Scanner value = new Scanner(System.in);
        System.out.println("Enter a number for factorial: ");
        int inputNum = value.nextInt();
        value.close();
        fact(inputNum);
        Recursion obj = new Recursion();
        System.out.println("The Factorial of " + inputNum + " is " + obj.factor(inputNum) + ".");
    }
}
